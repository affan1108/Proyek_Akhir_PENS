<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <p>Name : {{$data['name']}}</p><br>
    <p>E-mail : {{$data['email']}}</p><br>
    <p>Subject : {{$data['subject']}}</p><br>
    <p>Message : {{$data['message']}}</p><br>
</body>
</html>